# -*- coding: utf-8 -*-

###
### DO NOT CHANGE THIS FILE
### 
### The code is auto generated, your change will be overwritten by 
### code generating.
###
from __future__ import absolute_import

from .api.clients import Clients
from .api.clients_client_id import ClientsClientId


routes = [
    dict(resource=Clients, urls=['/clients'], endpoint='clients'),
    dict(resource=ClientsClientId, urls=['/clients/<int:client_id>'], endpoint='clients_client_id'),
]