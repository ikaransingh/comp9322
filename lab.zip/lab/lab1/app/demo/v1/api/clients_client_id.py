# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

from flask import request, g
import json
from . import Resource
from .. import schemas


class ClientsClientId(Resource):

    def get(self, client_id):
        print(client_id)
        id=str(client_id)
        clients = read_from_file()
        client = clients[id]
        print(client)


        return client, 200, None

def write_to_file(content):
    with open("./clients.json", "w") as clients:
        clients.write(json.dumps(content))


def read_from_file():
    with open("./clients.json", "r") as clients:
        return json.loads(clients.read())