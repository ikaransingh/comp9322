# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

from flask import request, g

from . import Resource
from .. import schemas

import json
class Clients(Resource):

    def post(self):
        print(g.json)
        client= read_from_file()
        print(client)
        ids=client.keys()
        id=[int(i) for i in ids]
        print(id)
        new_id = id[-1] + 1
        new_id=str(new_id)
        print(new_id,type(new_id))
        print(g.json['entity_type'])
        client[new_id] = {"entity_type": g.json['entity_type'], "year_established": g.json['year_established']}
        print(client)
        write_to_file(client)
        return client[new_id], 201, None

def write_to_file(content):
    with open("./clients.json", "w") as clients:
        clients.write(json.dumps(content))


def read_from_file():
    with open("./clients.json", "r") as clients:
        return json.loads(clients.read())