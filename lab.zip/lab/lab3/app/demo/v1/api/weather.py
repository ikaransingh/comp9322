# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
from rivescript import RiveScript
from flask import request, g
import os
from . import Resource
from .. import schemas

username='karan'
bot = RiveScript()
bot.load_directory(
    os.path.join(os.path.dirname(__file__),".","brain")
)
bot.sort_replies()

class Weather(Resource):

    def get(self):
        expression=g.args.get("expression")
        print("User says: %s" %expression)
        answer=bot.reply(username,expression)
        if "ERR" in answer:
            answer="Sorry, I don't know :("
        print("Returned answer: {}".format(answer))
        return {'answer':answer}, 200, None