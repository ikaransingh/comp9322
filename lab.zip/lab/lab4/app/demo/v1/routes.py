# -*- coding: utf-8 -*-

###
### DO NOT CHANGE THIS FILE
### 
### The code is auto generated, your change will be overwritten by 
### code generating.
###
from __future__ import absolute_import

from .api.weather import Weather
from .api.restaurants import Restaurants


routes = [
    dict(resource=Weather, urls=['/weather'], endpoint='weather'),
    dict(resource=Restaurants, urls=['/restaurants'], endpoint='restaurants'),
]