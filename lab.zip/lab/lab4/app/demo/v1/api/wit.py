import requests
from .credentials import WIT_TOKEN
from .weather_api import get_weather_info
from .yelp_api import get_yelp_info


def wit(expression):
    answer = ''
    try:
        result = requests.get('https://api.wit.ai/message?v=20201105&q={}'.format(expression),
                              headers={'Authorization': WIT_TOKEN})

        json_result = result.json()
        if json_result['intents'][0]['name'] == 'GetWeatherCondition':
            location = json_result['entities']['wit$location:location'][0]['body']
            print('location detected: {}'.format(location))
            answer = get_weather_info(location)
        if json_result['intents'][0]['name'] == 'GetRestaurants':
            location = json_result['entities']['wit$location:location'][0]['body']
            print('location detected: {}'.format(location))
            answer = get_yelp_info(location)
    except:
        answer = 'I do not understand :('
    return answer
