import requests
from .credentials import WEATHER_API_KEY


def get_weather_info(location):
    result = requests.get('https://api.openweathermap.org/data/2.5/weather?q={}&appid={}&units=metric'
                          .format(location, WEATHER_API_KEY))
    json_result = result.json()
    return f"It is {json_result['weather'][0]['description']} " \
           f"with max temperature of {json_result['main']['temp_max']} " \
           f"Centigrade and min temperature of {json_result['main']['temp_min']} " \
           f"Centigrade but feels like {json_result['main']['feels_like']} Centigrade in {json_result['name']}"